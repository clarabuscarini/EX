#include<stdio.h>
#include<conio.h>

int main()
{
	;float NRcoelhos, custo
	;printf("digite a quantidade de coelhos")
	;scanf("%s", & NRcoelhos)
	;custo<-(NRcoelhos*0,70)/18+10
	;printf("com", NRcoelhos,"coelhos,o valor do custo sera de", custo)
	
	;return 0	
;}


